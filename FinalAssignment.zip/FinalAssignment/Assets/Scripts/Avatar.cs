﻿using UnityEngine;
using System.Collections;

public class Avatar : MonoBehaviour {
    Rigidbody rigid;
    public float speed;
	// Use this for initialization
	void Start () {
        rigid = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.A))
        {
            rigid.AddTorque(-Vector3.up * speed);
        }
        else if(Input.GetKey(KeyCode.D))
        {
            rigid.AddTorque(Vector3.up * speed);
        }
        else if (Input.GetKey(KeyCode.W))
        {
            rigid.AddRelativeForce(Vector3.forward * speed);
        }
        else if (Input.GetKey(KeyCode.S))
        {
            rigid.AddRelativeForce(-Vector3.forward * speed);
        }

    }
}
